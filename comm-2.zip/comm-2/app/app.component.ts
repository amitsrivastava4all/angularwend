import { Component, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { interval } from 'rxjs';
import { CommonService } from './common.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'comm2';
  constructor(private commonService:CommonService){

  }
  ngOnInit(): void {
    let obs:Observable<number> = this.commonService.loadRX();
    var sb = obs.subscribe(val=>this.title=val.toString());
    setTimeout(()=>sb.unsubscribe(),10000);

  //   let obs:Observable<number> = interval(2000);
  //   let sub:Subscription = obs.subscribe(val=>{console.log('Value is ',val)
  //   this.title = 'Value is '+val;
  // },err=>console.log('Error is ',err)
  //   ,()=>console.log('Completed....'));
  //   setTimeout(()=> sub.unsubscribe(),20000);

  }
}
