import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})
export class SecondComponent implements OnInit {
  title:string='';
  constructor(private commonService:CommonService){

  }

  ngOnInit(): void {
    let obs:Observable<number> = this.commonService.loadRX();
    obs.subscribe(val=>this.title=val.toString());
  }

}
