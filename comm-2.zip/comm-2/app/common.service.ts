import { Injectable } from '@angular/core';
import { interval, Observable, Subscription } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
   obs:Observable<number>;
  constructor() {

    this.obs = interval(2000);
  }

  loadRX():Observable<number>{
    return this.obs;

}
}
