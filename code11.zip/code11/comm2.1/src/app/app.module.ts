import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { SecondComponent } from './second/second.component';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { CommonInterceptor } from './utils/common.interceptor';
@NgModule({
  declarations: [
    AppComponent,
    SecondComponent
  ],
  imports: [
    BrowserModule, HttpClientModule
  ],
  providers: [{provide:HTTP_INTERCEPTORS,
    useClass:CommonInterceptor,multi:true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
