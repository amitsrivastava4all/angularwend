import { HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Observable } from "rxjs";

export class CommonInterceptor implements HttpInterceptor{
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        console.log('Inside Interceptor....');
        if(req.url=='login'){
            return next.handle(req);
        }
        // let clone = req.clone(
        //     {
        //         headers:new HttpHeaders().append('Authorization'
        //         ,localStorage.tokenId)
        //     }
        // );
        let clone = req.clone();

        return next.handle(clone);
    }

}