export class Singer{
    name:string;
    photo:string;
    constructor(name:string, photo:string){
        this.name = name;
        this.photo = photo;
    }
}