import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CommonService } from '../common.service';
import { Singer } from '../models/singer';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})
export class SecondComponent implements OnInit {
  title:string='';
   obs2:Observable<Singer[]>
  //singers:[]= [];
  singers:Singer[] = [];
  isLoading:boolean;
  constructor(private commonService:CommonService){
    this.isLoading = false;
  }

 // async callServer(evt) {
  callServer(evt) {
    this.isLoading = true;
    //let obs:Observable<Singer[]>  = await this.commonService.serverCall();
    let obs:Observable<Singer[]>  =  this.commonService.serverCall();
    this.obs2  = obs;
    console.log('Before.....');
    obs.subscribe((data)=>{
      console.log('Singer are ',data);
      this.singers = data['singers'];
      //this.isLoading = false;

  },err=>console.log('Error in Server Call'),()=>{
    console.log('Completed....');
    this.isLoading = false;
  });
  console.log('After.....');
    /*let obs:Observable<Object>  = this.commonService.serverCall();
    obs.subscribe(data=>{this.singers = data['singers']
    this.isLoading = false;
  },err=>console.log('Error in Server Call'));
  */
  }

  ngOnInit(): void {
    // let obs:Observable<number> = this.commonService.loadRX();
    // obs.subscribe(val=>this.title=val.toString());
    let obs1:Observable<string>= this.commonService.getSubject();

    obs1.subscribe(data=>this.title = data,
      err=>this.title = 'Error in Subject '+err,()=>
      this.title ='Obs Completed');
  }

}
