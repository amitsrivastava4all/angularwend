import { Component, OnInit, OnDestroy,
   OnChanges, SimpleChanges, DoCheck,
   AfterViewInit, Input } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements
OnInit,OnDestroy,OnChanges,DoCheck,AfterViewInit {
  @Input()
  share:string;
  title:string;
  constructor() {
    console.log('1. Constructor Call');
  }
  ngAfterViewInit(): void {
    console.log('Wait for Child to Be loaded...');
  }
  ngDoCheck(): void {
    console.log('3. Call After NgOnInit , Event Fire... ');
  }
  eventFire(evt){
    var x:number = 100;
    console.log('Event Fire......');
  }
  ngOnChanges(changes: SimpleChanges): void {
    if(this.share.length>4){
      this.title = 'Share Value > 4';
    }
    console.log('3. Changes @Input Parameter Changes ',changes)
  }


  ngOnDestroy(): void {
    // resource clean up
  }


  ngOnInit(): void {
    //backend call
    console.log('2. NgOnInit Call');
  }

}
