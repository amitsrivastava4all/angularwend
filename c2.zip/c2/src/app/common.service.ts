import { Injectable } from '@angular/core';
import { interval, Observable, Subscription, BehaviorSubject } from 'rxjs';
import {HttpClient} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class CommonService {
   obs:Observable<number>;
   bh:BehaviorSubject<string>;
  constructor(private http:HttpClient) {
    this.bh = new BehaviorSubject<string>('');
    this.obs = interval(2000);
  }

  getSubject():BehaviorSubject<string>{
    return this.bh;
  }

  shareMyData(data:string){
    this.bh.next(data);
  }

  serverCall():Observable<Object>{
    var obj = {}; // contains data to post
    //return this.http.post(url, obj);
    //this.http.get(url).toPromise();
    return this.http.get('https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/singers.json');
  }

  storeData( myData:string):Observable<string>{
    // Old Way Observable.create(observer);
    let obs:Observable<string> =
    new Observable<string>(observer=>{
      //fetch(url)
      observer.next(myData);
    });
    return obs;
  }

  loadRX():Observable<number>{
    return this.obs;

}
}
