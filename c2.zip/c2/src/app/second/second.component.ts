import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})
export class SecondComponent implements OnInit {
  title:string='';
  singers:[]= [];
  constructor(private commonService:CommonService){

  }

  callServer(evt){
    let obs:Observable<Object>  = this.commonService.serverCall();
    obs.subscribe(data=>this.singers = data['singers'],err=>console.log('Error in Server Call'));
  }

  ngOnInit(): void {
    // let obs:Observable<number> = this.commonService.loadRX();
    // obs.subscribe(val=>this.title=val.toString());
    let obs1:Observable<string>= this.commonService.getSubject();

    obs1.subscribe(data=>this.title = data,
      err=>this.title = 'Error in Subject '+err,()=>
      this.title ='Obs Completed');
  }

}
