import { ThrowStmt } from '@angular/compiler';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {MyModel} from '../models/mymodel';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})
export class SecondComponent implements OnInit {
  myName:string;
  myData:string;
  @Input('sendtosecond')
  passtosecond:string;
  @Output('callme')
  childCallMe:EventEmitter<MyModel> =new EventEmitter<MyModel>();
  //childCallMe:EventEmitter<string> =new EventEmitter<string>();
  constructor() {
    this.myData = '';
  }

  show(){
    console.log('I am Second ',this.myName);
    return this.myName;
  }
  ngOnInit(): void {
  }

  takeData(event){
    this.myData = event.target.value;
    console.log('Second Data ',this.myData);
    let myModel:MyModel  = new MyModel();
    myModel.name = this.myData;
    myModel.age = 21;
    myModel.salary = 9999;
    //myModel.
    //this.childCallMe.emit(this.myData);
    this.childCallMe.emit(myModel);
  }

}
