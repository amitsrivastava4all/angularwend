import { MyserviceService } from './../myservice.service';
import { SecondComponent } from './second/second.component';
import { Component, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { MyModel } from './models/mymodel';
import { ThirdComponent } from '../third/third.component';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css'],
  //providers:[MyserviceService]
})
export class FirstComponent implements OnInit {
  @ViewChild(SecondComponent)
  second:SecondComponent ;
  @ViewChildren(ThirdComponent)
  thirdList:QueryList<ThirdComponent>;
  name:string;
  dataRecFromChild:String;
  constructor(private myService:MyserviceService) {
    this.name = '';
    this.dataRecFromChild = '';
  }

 // giveMeData(data:string){
  giveMeData(myModel:MyModel){
    console.log('Data Rec from child ',myModel);
    this.dataRecFromChild = myModel.name+ " " + myModel.age + " "+myModel.salary+" "+myModel.calc(100,200);
  }

  callSecond(event){
    console.log('Second Obj is ',this.second);
    this.second.myName = this.name; // P to C
    this.name = this.second.show(); // C to P
  }

  ngOnInit(): void {
  }
  takeInput(event){
    this.name = event.target.value;
    this.myService.setData(this.name);
    this.thirdList.forEach(thirdComp=>
      thirdComp.setMessage(this.name + ' '+Math.random() ));
  }

}
