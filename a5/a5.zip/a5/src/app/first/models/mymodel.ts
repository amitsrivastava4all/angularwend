export class MyModel{
    name:string;
    age:number;
    salary:number;
    calc(x,y){
        return x + y;
    }

}