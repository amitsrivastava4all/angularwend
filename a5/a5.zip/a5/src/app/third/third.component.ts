import { MyserviceService } from './../myservice.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-third',
  templateUrl: './third.component.html',
  styleUrls: ['./third.component.css'],
  //providers:[MyserviceService]
})
export class ThirdComponent implements OnInit {
  msg:string;
  constructor(private myService:MyserviceService) {
    this.msg = '';
  }
  setMessage(msg:string){
    this.msg = msg;
  }

  ngOnInit(): void {
  }
  getServiceData(event){
    this.msg = this.myService.getData();
  }

}
