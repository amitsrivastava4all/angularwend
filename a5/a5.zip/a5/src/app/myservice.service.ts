import { Injectable } from '@angular/core';

 @Injectable({
   providedIn: 'root'
 })
//@Injectable()
export class MyserviceService {
  data:string;
  constructor() { }
  setData(data:string){
    this.data = data + 'Service ::::';
  }
  getData(){
    return this.data;
  }
}

